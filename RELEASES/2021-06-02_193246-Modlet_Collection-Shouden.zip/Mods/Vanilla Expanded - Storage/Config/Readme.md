* Added:
* Block, Icon and localization entry for cntStorageGenericHalf
* Block, Icon and localization entry for cntStorageGenericHalfInsecure
* Block and localization entry for cntPlayerFireWoodStack
* Block and localization entry for cntPlayerCementBagStack
* Block and localization entry for cntPlayerBlueTarp
* Block and localization entry for cntPlayerBrownBoxes
* Block and localization entry for cntPlayerBrickPile
* Block and localization entry for cntPlayerMedicLootPileSmall
* Block and localization entry for cntPlayerBarrelPlasticSingle00
* Block and localization entry for cntPlayerBarrelPlasticQuadA
* Block and localization entry for cntPlayerMedicLootPileMedium
* Block and localization entry for cntPlayerWaterCoolerFull
* Block and localization entry for cntPlayerFoodPileSmall
* Block and localization entry for cntPlayerFoodPileMedium
* Block and localization entry for cntPlayerFoodPileLarge
* Block and localization entry for cntPlayerAmmoPileSmall
* Block and localization entry for cntPlayerAmmoPileMedium
* Block and localization entry for cntPlayerAmmoPileLarge
* Block and localization entry for cntPlayerWeaponsBagSmall
* Block and localization entry for cntPlayerWeaponsBagLarge
* Block and localization entry for cntPlayerClothesShelfStackShirts02
* Block and localization entry for cntPlayerLaundryBasketVer2Full
* Block and localization entry for cntLuggageMediumClosed
* Block and localization entry for cntLuggagePileBClosed
* Block and localization entry for cntPlayerBookPile01
* Block and localization entry for cntPlayerBookPile04
* Block and localization entry for cntPlayerDuffle01
* Block and localization entry for cntPlayerBackpack03
* Block and localization entry for cntPlayerTrashPile09
* Block and localization entry for cntPlayerCardboardBox
* Block and localization entry for cntPlayerBarrelRadiatedQuadA
* Block and localization entry for cntPlayerBarrelRadiatedSingle00
* Block and localization entry for cntPlayerBarrelOilQuadA
* Block and localization entry for cntPlayerBarrelOilSingle00
* Block and localization entry for cntPlayerBarrelGenericQuadA
* Block and localization entry for cntPlayerBarrelGasQuadA
* Block and localization entry for cntPlayerBarrelGasSingle00
* Block and localization entry for cntPlayerBarrelAcidQuadA
* Block and localization entry for cntPlayerBarrelAcidSingle00
* Block and localization entry for cntPlayerScrapMetalPile
* Block and localization entry for cntPlayerHardenedChestSecure
* Block and localization entry for cntPlayerClothesRackRoundPants
* Block and localization entry for cntPlayerClothesRackRectanglePants
* Block and localization entry for cntPlayerGunRackSmallMagazines
* Block and localization entry for cntPlayerGunRackSmallArmor
* Block and localization entry for cntPlayerGunRackLargeGuns01
* Block and localization entry for cntPlayerGunRackLargeGuns02
* Block and localization entry for cntPlayerMedicineCabinetClosed
* Block and localization entry for cntPlayerPillCaseClosed
* Block and localization entry for cntPlayerMunitionsBox
* Block and localization entry for cntPlayerVendingMachine
* Block and localization entry for cntPlayerFileCabinetShortClosed
* Block and localization entry for cntPlayerFileCabinetTallClosed
* Custom container loot lists for new containers 


* Changed:
* XUi loot window to fit custom container names
* Custom container sizes to 6x8