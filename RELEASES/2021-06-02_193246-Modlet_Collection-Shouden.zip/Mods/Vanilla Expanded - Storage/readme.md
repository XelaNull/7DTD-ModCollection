1.0.4

Added:
* Block, icon, and localization for cntPlayerGarmentBag
* Block, icon, and localization for cntPlayerClosetRod
* Block, icon, and localization for cntPlayerToolBoxClosed
* Block, icon, and localization for cntPlayerRollingToolBoxClosed


1.0.3

Fixed:
* Incorrect max damage value for cntPlayerWaterCoolerFull
* Incorrect max damage value for cntPlayerMedicLootPileSmall
* Incorrect max damage value for cntPlayerMedicLootPileMedium
* Incorrect max damage value for cntPlayerFoodPileSmall
* Incorrect max damage value for cntPlayerFoodPileMedium
* Incorrect max damage value for cntPlayerFoodPileLarge

Added:
* Block, icon, and localization for cntPlayerBarrelWoodVert
* Block, icon, and localization for cntPlayerBarrelWoodHor
* Block, icon, and localization for cntPlayerBarrelWoodSet
* Block, icon, and localization for cntPlayerCooler
* Block, icon, and localization for cntPlayerBookcaseFull

1.0.2

Fixed:
* Furniture Variant using wrong Luggage blocks 

1.0.1

Changed:
* Updated custom loot list sounds 

1.0.0

Added:
* Block, Icon and localization entry for cntStorageGenericHalf
* Block, Icon and localization entry for cntStorageGenericHalfInsecure
* Block and localization entry for cntPlayerFireWoodStack
* Block and localization entry for cntPlayerCementBagStack
* Block and localization entry for cntPlayerBlueTarp
* Block and localization entry for cntPlayerBrownBoxes
* Block and localization entry for cntPlayerBrickPile
* Block and localization entry for cntPlayerMedicLootPileSmall
* Block and localization entry for cntPlayerBarrelPlasticSingle00
* Block and localization entry for cntPlayerBarrelPlasticQuadA
* Block and localization entry for cntPlayerMedicLootPileMedium
* Block and localization entry for cntPlayerWaterCoolerFull
* Block and localization entry for cntPlayerFoodPileSmall
* Block and localization entry for cntPlayerFoodPileMedium
* Block and localization entry for cntPlayerFoodPileLarge
* Block and localization entry for cntPlayerAmmoPileSmall
* Block and localization entry for cntPlayerAmmoPileMedium
* Block and localization entry for cntPlayerAmmoPileLarge
* Block and localization entry for cntPlayerWeaponsBagSmall
* Block and localization entry for cntPlayerWeaponsBagLarge
* Block and localization entry for cntPlayerClothesShelfStackShirts02
* Block and localization entry for cntPlayerLaundryBasketVer2Full
* Block and localization entry for cntLuggageMediumClosed
* Block and localization entry for cntLuggagePileBClosed
* Block and localization entry for cntPlayerBookPile01
* Block and localization entry for cntPlayerBookPile04
* Block and localization entry for cntPlayerDuffle01
* Block and localization entry for cntPlayerBackpack03
* Block and localization entry for cntPlayerTrashPile09
* Block and localization entry for cntPlayerCardboardBox
* Block and localization entry for cntPlayerBarrelRadiatedQuadA
* Block and localization entry for cntPlayerBarrelRadiatedSingle00
* Block and localization entry for cntPlayerBarrelOilQuadA
* Block and localization entry for cntPlayerBarrelOilSingle00
* Block and localization entry for cntPlayerBarrelGenericQuadA
* Block and localization entry for cntPlayerBarrelGasQuadA
* Block and localization entry for cntPlayerBarrelGasSingle00
* Block and localization entry for cntPlayerBarrelAcidQuadA
* Block and localization entry for cntPlayerBarrelAcidSingle00
* Block and localization entry for cntPlayerScrapMetalPile
* Block and localization entry for cntPlayerHardenedChestSecure
* Block and localization entry for cntPlayerClothesRackRoundPants
* Block and localization entry for cntPlayerClothesRackRectanglePants
* Block and localization entry for cntPlayerGunRackSmallMagazines
* Block and localization entry for cntPlayerGunRackSmallArmor
* Block and localization entry for cntPlayerGunRackLargeGuns01
* Block and localization entry for cntPlayerGunRackLargeGuns02
* Block and localization entry for cntPlayerMedicineCabinetClosed
* Block and localization entry for cntPlayerPillCaseClosed
* Block and localization entry for cntPlayerMunitionsBox
* Block and localization entry for cntPlayerVendingMachine
* Block and localization entry for cntPlayerFileCabinetShortClosed
* Block and localization entry for cntPlayerFileCabinetTallClosed
* Custom container loot lists for new containers 


Changed:
* XUi loot window to fit custom container names
* Custom container sizes to 6x8
